alias errcho='>&2 echo'

# Returns the name of the config file to use. This inspects its argument and
# checks if such a file exists. If the argument is non-empty and the file does
# not exist, returns non-zero. If BUILD_CONFIG is empty, returns the path to the
# default configuration.
which_config() {
  if [[ -z $1 ]]; then
    if [[ -f $DEFAULT_BUILD_CONFIG ]]; then
      # User-defined build file with default name exists.
      echo $DEFAULT_BUILD_CONFIG
    else
      # Use the system default build config.
      echo $CODE_PATH/$DEFAULT_BUILD_CONFIG
    fi
  elif [[ ! -f $1 ]]; then
    # User specified a build file but it is not a regular file.
    echo $1
    return 1
  fi
}

# Check if a stanza exists.
stanza_exists() { grep -q "^$1 *{$" $BUILD_CONFIG }

# Extract a stanza from the config.
config_stanza() { sed "0,/^$1 *{$/d;/^}$/,\$d;s/^ *//" $BUILD_CONFIG }

# Generate the configuration for a given mode.
config() {
  config_stanza default
  if [[ $1 != default ]]; then
    config_stanza $1
  fi
}

# Get the value of a make variable from the configuration.
make_variable() {
  make -sf <(
    echo '.PHONY: default'
    echo 'default: print_var'
    config $MODE
    echo '.PHONY: print_var'
    echo 'print_var:'
    echo "	echo \${$1}"
  )
}

# Find the name of the target binary. This is the basename of whatever file
# defines main.
target_name() {
  local CXXFLAGS=$(make_variable CXXFLAGS)

  for file in $SOURCE_PATH/*.cc; do
    if clang++ $=CXXFLAGS -E $file | grep -qP '^\s*int\s+main\s*\('; then
      # Display the filename with both the path and extension stripped.
      echo ${file:r:t}
      return 0
    fi
  done
  echo "a.out"
  return 1
}

# Generate a dummy make rule for the given file which will touch it if any of
# its dependencies have changed. This will force make to regenerate anything
# that depends on it.
deps() {
  local DEPENDENCY_PATTERN='(?<=^#include ").*(?=")'
  local NUM_DEPS=$(grep -cP $DEPENDENCY_PATTERN $1)
  if [[ $NUM_DEPS -gt 0 ]]; then
    printf '%s:' $1
    grep -oP $DEPENDENCY_PATTERN $1 |
    awk '{print "'$SOURCE_PATH'/" $1}' |
    tr '\n' ' ' |
    fold -s -w $((80 - DEPENDENCY_INDENT - 3)) |
    xargs -n1 -d '\n' printf '  \\\n%'$DEPENDENCY_INDENT's%s' ''
    printf '\n\ttouch $@\n'
    echo
  fi
}

# List of source files.
sources() {
  find $SOURCE_PATH -name '*.cc' -or -name '*.h' |
  sort
}

# Generate dummy make rules for all source files.
all_deps() {
  for file in $(sources); deps $file
}
