# Static configuration.
BINARY_PATH=bin
OBJECT_PATH=obj
SOURCE_PATH=src

# Internals-only configuration.
DEFAULT_BUILD_CONFIG=build.config
DEPENDENCY_INDENT=4
