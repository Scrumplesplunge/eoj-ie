#!/usr/bin/zsh

# This script makes a few assumptions about the structure of a project:
#   * All external headers are included with #include <foo>
#   * All internal headers are included with #include "foo"
#   * All source files are in $SOURCE_PATH/
#   * There are no source files in subdirectories of $SOURCE_PATH/
#   * The project produces exactly one binary, and therefore exactly one source
#     file defines the main function.

CODE_PATH=~/scripts/build
source $CODE_PATH/static_config.zsh
source $CODE_PATH/functions.zsh
source $CODE_PATH/config.zsh

MAKEFILE=$(mktemp)
_trap_exit() { rm $MAKEFILE }
trap _trap_exit EXIT

source $CODE_PATH/makefile.zsh >> $MAKEFILE

mkdir -p $BINARY_PATH
BUILD_LOG=$BINARY_PATH/$MODE.log
>$BUILD_LOG <<EOF
Build started $(date +'on %Y-%m-%d, at %H:%M:%S').

Static settings:

  BINARY_PATH = ${BINARY_PATH}
  OBJECT_PATH = ${OBJECT_PATH}
  SOURCE_PATH = ${SOURCE_PATH}

Flag settings:

  BUILD_CONFIG = ${BUILD_CONFIG}
  DRY_RUN      = ${DRY_RUN}
  MODE         = ${MODE}
  OPERATION    = ${OPERATION}
  SHOW_HELP    = ${SHOW_HELP}

==== Makefile ==================================================================
$(<$MAKEFILE)
================================================================================

EOF

if [[ $DRY_RUN == no ]]; then
  if [[ $OPERATION == run ]]; then
    # Ensure that the binary is built, and that the build is logged.
    make -f $MAKEFILE -j $(nproc --all) build >> $BUILD_LOG
    # Run the binary such that all output is from the binary.
    make -f $MAKEFILE -s run
  else
    # Perform the operation and log it.
    make -f $MAKEFILE -j $(nproc --all) $OPERATION >> $BUILD_LOG
  fi
fi
