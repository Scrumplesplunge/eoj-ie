<<EOF
.PHONY: build internal-default
build: internal-default

# Inferred target name (may be overridden by configuration).
TARGET = $(target_name)

# Configuration settings from build.config:
$(config $MODE)

# By default, build the target binary.
.PHONY: internal-default
$(echo "internal-default: ${BINARY_PATH}/${MODE}/\${TARGET}")

# Run the target binary.
.PHONY: run
$(echo "run: ${BINARY_PATH}/${MODE}/\${TARGET}")
	$(echo "${BINARY_PATH}/${MODE}/\${TARGET} ${ESCAPED_FLAGS}")

# Clean up all generated files.
.PHONY: clean
clean:
	rm -rf ${BINARY_PATH} ${OBJECT_PATH}

# Create the binary directory.
${BINARY_PATH}/${MODE}:
	mkdir -p $(echo '$@')

# Create the object directory.
${OBJECT_PATH}/${MODE}:
	mkdir -p $(echo '$@')

# Pattern rule for compiling a *.cc file.
${OBJECT_PATH}/${MODE}/%.o: ${SOURCE_PATH}/%.cc | ${OBJECT_PATH}/${MODE}
	$(echo '${CXX} $< -c -o $@ ${CPPFLAGS} ${CXXFLAGS}')

# Dummy rules for ensuring that incremental builds are correct.
$(all_deps)

# Enumerate all sources and their corresponding object files.
SOURCES = $(
  echo "\$(shell find $SOURCE_PATH -name '*.cc')"
)
OBJECTS = $(
  echo "\$(patsubst $SOURCE_PATH/%.cc, $OBJECT_PATH/$MODE/%.o, \${SOURCES})"
)

# Build the target binary.
$(echo "$BINARY_PATH/$MODE/\${TARGET}: \${OBJECTS} | $BINARY_PATH/$MODE")
	$(echo '${CXX} $^ -o $@ ${LDFLAGS}')
EOF
