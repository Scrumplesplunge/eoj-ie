>&2 <<EOF
Usage: jb [options]

  build              Build the project. This is the default option if the
                     operation is not specified.

  clean              Delete all generated files.

  init               Initialize the build file from the template build file. If
                     --build-file is specified then that file will be populated.
                     Otherwise, the default build file name will be used, and it
                     will be created in the current working directory.

  run                Execute the generated binary. Any flags beyond -- are
                     passed to the generated binary.

  --                 Stop argument processing.

  -d                 Perform a dry-run of whatever build command has been
  --dry-run          specified. This will display the generated makefile and the
                     invocation that is being used.

  -f=file            Specify the name of the build configuration file. If left
  --build-file=file  unspecified, the system-wide default configuration will be
                     used unless there is a regular file within the current
                     working directory which is called ${DEFAULT_BUILD_CONFIG}.

  -h                 Show this help message.
  --help
  help

  -m=mode            Select build mode. This should match the name of one of the
  --mode=mode        stanzas in the build configuration file.
EOF
