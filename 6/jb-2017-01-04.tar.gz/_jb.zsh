#compdef jb

CODE_PATH=~/scripts/build
source $CODE_PATH/static_config.zsh
source $CODE_PATH/functions.zsh

_modes() {
  local BUILD_FILE
  if [[ ! -z $opt_args[-f] ]]; then
    BUILD_FILE=$opt_args[-f]
  fi
  if [[ ! -z $opt_args[--build-files] ]]; then
    BUILD_FILE=$opt_args[--build-files]
  fi
  BUILD_FILE=$(which_config $BUILD_FILE)
  if [[ $? -ne 0 ]]; then
    # Build file was specified, but does not exist.
    compadd
  else
    # Complete using the build file.
    compadd $(grep -oP '^[A-Za-z]+(?=\s*\{$)' $BUILD_FILE)
  fi
}

_jb() {
  local curcontext="$curcontext" state line
  typeset -A opt_args

  _arguments -S  \
      '1: :(build clean init run help)'  \
      '--dry-run: :'  \
      '-f=-: :_files'  \
      '--build-files=-: :_files'  \
      '-m=-: :_modes'  \
      '--mode=-: :_modes'
}

_jb $@
