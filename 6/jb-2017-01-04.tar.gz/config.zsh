help_message() {
  source $CODE_PATH/help_message.zsh
}

# Process the command line flags.
BUILD_CONFIG=
DRY_RUN=no
MODE=default
OPERATION=build
SHOW_HELP=no

for ((i = 1; i <= $#; i++)); do
  flag=${@[$i]}
  case $flag in
    --)
      ESCAPED_FLAGS=${@:$((i + 1)):q}
      break
      ;;
    -h|--help|help)
      SHOW_HELP=yes
      ;;
    -m=*|--mode=*)
      MODE=${flag#*=}
      ;;
    -d|--dry-run)
      DRY_RUN=yes
      ;;
    -f=*|--build-file=*)
      BUILD_CONFIG=${flag#*=}
      ;;
    build)
      OPERATION=build
      ;;
    clean)
      OPERATION=clean
      ;;
    init)
      OPERATION=init
      ;;
    run)
      OPERATION=run
      ;;
    *)
      errcho "Unrecognised flag '$flag'."
      exit 1
      ;;
  esac
done

if [[ $SHOW_HELP == yes ]]; then
  # Show the help message and then exit.
  if [[ $# -gt 1 ]]; then
    errcho 'Warning: ignoring all flags except for --help.'
  fi
  help_message
  if [[ $# -gt 1 ]]; then
    exit 1
  else
    exit 0
  fi
fi

# Early exit if handling the init operation.
if [[ $OPERATION == init ]]; then
  if [[ -a $BUILD_CONFIG ]]; then
    errcho "Build file '$BUILD_CONFIG' already exists."
    exit 1
  fi

  # Copy the template build config.
  <$CODE_PATH/$DEFAULT_BUILD_CONFIG >$BUILD_CONFIG
  if [[ $? -ne 0 ]]; then
    errcho "Failed to write build file '$BUILD_CONFIG'."
    exit 1
  fi

  exit 0
fi

# Validate the BUILD_CONFIG value.
BUILD_CONFIG=$(which_config $BUILD_CONFIG)
if [[ $? -ne 0 ]]; then
  errcho "Build config '$BUILD_CONFIG' does not exist or is not a regular file."
  exit 1
fi

if ! stanza_exists default; then
  errcho "Build file does not provide a 'default' stanza."
  exit 1
elif ! stanza_exists $MODE; then
  errcho "Build file does not provide a '$MODE' stanza."
  exit 1
fi
